package com.example.cartanditem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartanditemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartanditemApplication.class, args);
	}

}
