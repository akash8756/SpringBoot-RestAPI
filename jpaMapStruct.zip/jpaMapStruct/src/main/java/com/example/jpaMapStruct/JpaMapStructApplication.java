package com.example.jpaMapStruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaMapStructApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaMapStructApplication.class, args);
	}

}
